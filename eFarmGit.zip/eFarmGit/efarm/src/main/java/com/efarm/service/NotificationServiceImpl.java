package com.efarm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.efarm.dao.INotificationDao;
import com.efarm.dao.IOrderDao;
import com.efarm.dao.IProduct;
import com.efarm.dao.IWalletDao;
import com.efarm.entity.Notifications;
import com.efarm.entity.OrderHistory;
import com.efarm.entity.Wallet;
import com.efarm.entity.productInfo;

@Service
public class NotificationServiceImpl implements INotificationService {
	@Autowired
	INotificationDao dao;
	@Autowired
	IWalletDao dao2;
	@Autowired
	IOrderDao dao3;
	@Autowired
	IProduct dao4;
	
	@Override
	public boolean addNotification(Notifications user) {

		Notifications not = new Notifications();
		not.setNotificationType("status");
		not.setMobileNumber(user.getMobileNumber());
		not.setAmount(user.getAmount());
		not.setContent(user.getAmount()+" add Money request is sent to the admin");
		dao.save(not);
		
		dao.save(user);

		return true;
	}

	@Override
	public List<Notifications> getUserNotification(Long phoneNo) {

		// List<Notifications> notifications = dao2.findAllByMobileNumber(phoneNo);

		return null;
	}

	@Override
	public List<Notifications> getAllNotifications() {

		return dao.findAll();
	}

	@Override
	public boolean approveMoney(Wallet wallet) {
		
		long newbal,addBal=wallet.getWalletBalance();
		Notifications not = new Notifications();
		not = dao.findById(wallet.getMobileNumber()).orElse(null);
		wallet.setMobileNumber(not.getMobileNumber());
		
		Wallet wal = new Wallet();
		wal = dao2.findById(wallet.getMobileNumber()).orElse(null);
		if (wal != null) {
			newbal = wal.getWalletBalance() + wallet.getWalletBalance();
			wallet.setWalletBalance(newbal);
			dao2.save(wallet);
		} else {

			dao2.save(wallet);
		}
		dao.deleteById(not.getNotificationId());
		Notifications not2 = new Notifications();
		not2.setNotificationType("status");
		not2.setMobileNumber(not.getMobileNumber());
		not2.setAmount(wallet.getWalletBalance());
		not2.setContent(addBal +" add Money request is approved by the admin");
		dao.save(not2);
		return true;
	}

	@Override
	public boolean rejectMoney(Wallet user) {
		Notifications not = new Notifications();
		not = dao.findById(user.getMobileNumber()).orElse(null);
		user.setMobileNumber(not.getMobileNumber());
		not.setNotificationType("status");
		not.setMobileNumber(user.getMobileNumber());
		not.setAmount(user.getWalletBalance());
		not.setContent(user.getWalletBalance() +" add Money request is rejected by the admin");
		dao.save(not);
		dao.deleteById(not.getNotificationId());
		return true;
	}

	@Override
	public Wallet getWalletBalance(Long phoneNo) {
		
		return dao2.findById(phoneNo).orElse(null);
	}

	@Override
	public boolean PlaceOrder(OrderHistory order) {
		productInfo product = new productInfo();
		Notifications not = new Notifications();
		Wallet wal = new Wallet();
		product = dao4.findById(order.getProductId()).orElse(null);
		not.setMobileNumber(order.getCustomerId());
		not.setAmount(order.getCost());
		not.setNotificationType(order.getStatus());
		not.setContent(product.getProductName() +" Order notification sent to Seller. Awaiting from seller");
		wal = dao2.findById(order.getCustomerId()).orElse(null);
		
		wal.setWalletBalance(wal.getWalletBalance() - order.getCost());
		dao.save(not);
		dao2.save(wal);
		dao3.save(order);
		return true;
	}

	@Override
	public List<OrderHistory> getAllOrdersList() {
		
		return dao3.findAll();
	}

	@Override
	public boolean sellOrder(OrderHistory order) {
		
		productInfo product = new productInfo();
		Notifications not = new Notifications();
		product = dao4.findById(order.getProductId()).orElse(null);
		not.setMobileNumber(order.getCustomerId());
		not.setAmount(order.getCost());
		not.setNotificationType("Sold Complete");
		not.setContent(product.getProductName()+" Order completed");	
		dao.save(not);
		order.setStatus("Sold Complete");	
		dao3.save(order);	
		product.setProductQuantity(product.getProductQuantity()-order.getQuantity());
		dao4.save(product);
		return true;
	}

	@Override
	public boolean rejectOrder(OrderHistory order) {
		Wallet wal = new Wallet();
		productInfo product = new productInfo();
		Notifications not = new Notifications();
		product = dao4.findById(order.getProductId()).orElse(null);
		not.setMobileNumber(order.getCustomerId());
		not.setAmount(order.getCost());
		not.setNotificationType("Order Cancelled");
		not.setContent(product.getProductName()+" Order Cancelled by the seller... Refund is added to your account");	
		dao.save(not);
		wal = dao2.findById(order.getCustomerId()).orElseGet(null);
		wal.setWalletBalance(wal.getWalletBalance() + order.getCost());
		dao2.save(wal);
		order.setStatus("Order Cancelled");	
		dao3.save(order);
		
		return true;
	}

}
