package com.efarm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EfarmApplication {

	public static void main(String[] args) {
		SpringApplication.run(EfarmApplication.class, args);
	}

}
