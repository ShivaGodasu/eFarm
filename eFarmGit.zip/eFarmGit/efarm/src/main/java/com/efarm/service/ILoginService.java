package com.efarm.service;

import com.efarm.entity.Login;

public interface ILoginService {

	public boolean login(Login login);

	public boolean register(Login login);

	public boolean changePasword(long mobNum, String curPass, String newPass);

	public boolean loginSeller(Login login);
}
