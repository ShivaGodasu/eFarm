package com.efarm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.efarm.entity.Notifications;
import com.efarm.entity.User;
import com.efarm.service.IUserService;

@CrossOrigin(origins = "http://localhost:4200")

@RestController
public class UserController {

	@Autowired
	IUserService service;

	@PostMapping(value = "/register", consumes = "application/json")
	public ResponseEntity<Boolean> register(@RequestBody User user) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.register(user));
	}

	@GetMapping(value = "/login", produces = "application/json")
	public boolean login(@RequestParam Long phoneNo, String password) {
		return service.login(phoneNo, password);
	}

	@GetMapping(value="/getUserName", produces = "application/json")
    public User getUserName(@RequestParam Long phoneNo)
    {
    	return service.getUserName(phoneNo);	
    }
	
	@PostMapping(value = "/editUser", consumes = "application/json")
	public ResponseEntity<Boolean> editUser(@RequestBody User user) {
		System.out.println(user);
		return ResponseEntity.status(HttpStatus.CREATED).body(service.editUser(user));
	}
	
	@PostMapping(value = "/addMoney", consumes = "application/json")
	public ResponseEntity<Boolean> addMoney(@RequestBody Notifications user) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.addNotification(user));
	}
	/*
	 * @GetMapping(value="/getUserNotification", produces = "application/json")
	 * public List<Notifications> getUserNotification(@RequestParam Long phoneNo) {
	 * return service.getUserNotification(phoneNo); }
	 */
}
