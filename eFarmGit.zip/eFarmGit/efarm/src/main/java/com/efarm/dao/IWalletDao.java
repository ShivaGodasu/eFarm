package com.efarm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.efarm.entity.Wallet;

@Repository
public interface IWalletDao extends JpaRepository<Wallet, Long> {

}
