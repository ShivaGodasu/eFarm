package com.efarm.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.efarm.dao.IProduct;
import com.efarm.entity.productInfo;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProduct dao;

	@Override
	public List<productInfo> getAllProductsList() {
		return dao.findAll();
	}

	@Override
	public boolean addProduct(productInfo product) {
		dao.save(product);
		return true;
	}

	@Override
	public productInfo getProductById(Long productId) {
		productInfo master = dao.findById(productId).orElse(null);

		return master;
	}
}
