package com.efarm.service;

import java.util.List;

import com.efarm.entity.productInfo;

public interface IProductService {

	List<productInfo> getAllProductsList();

	boolean addProduct(productInfo product);
	
	productInfo getProductById(Long productId);

	/*
	 * List<ProductMaster> getProductListByRange(double low, double high,String
	 * type);
	 * 
	 * List<ProductMaster> getProducts(String type);
	 * 
	 * ProductMaster getProductById(int productId);
	 * 
	 * List<FeedbackProduct> getFeedbackById(int productId);
	 * 
	 * int addtoWishList(int userId, int productid);
	 * 
	 * List<ProductMaster> getWishList(int userId);
	 * 
	 * int addtoCart(int userId, int productId);
	 */
}
