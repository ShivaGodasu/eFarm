package com.efarm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.efarm.entity.Notifications;
import com.efarm.entity.OrderHistory;
import com.efarm.entity.Wallet;
import com.efarm.service.INotificationService;

@CrossOrigin(origins = "http://localhost:4200")

@RestController
public class NotificationController {
	@Autowired
	INotificationService service;
	
	@GetMapping(path = "/getAllNotifications", produces = "application/json")
	public List<Notifications> getAllNotifications() {

		return service.getAllNotifications();
	}
	@PostMapping(value = "/addMoney", consumes = "application/json")
	public ResponseEntity<Boolean> addMoney(@RequestBody Notifications not) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.addNotification(not));
	}
	@PostMapping(value = "/rejectMoney", consumes = "application/json")
	public ResponseEntity<Boolean> rejectMoney(@RequestBody Wallet user) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.rejectMoney(user));
	}
	@PostMapping(value = "/approveMoney", consumes = "application/json")
	public ResponseEntity<Boolean> approveMoney(@RequestBody Wallet user) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.approveMoney(user));
	}
	
	@GetMapping(value = "/getWalletBalance", produces = "application/json")
	public Wallet getWalletBalance(@RequestParam Long phoneNo) {
		return service.getWalletBalance(phoneNo);
	}
	@PostMapping(value = "/placeOrder", consumes = "application/json")
	public ResponseEntity<Boolean> placeOrder(@RequestBody OrderHistory order) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.PlaceOrder(order));
	}
	
	@GetMapping(path = "/getAllOrdersList", produces = "application/json")
	public List<OrderHistory> getAllOrdersList() {

		return service.getAllOrdersList();
	}
	
	@PostMapping(value = "/sellOrder", consumes = "application/json")
	public ResponseEntity<Boolean> sellOrder(@RequestBody OrderHistory order) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.sellOrder(order));
	}
	@PostMapping(value = "/rejectOrder", consumes = "application/json")
	public ResponseEntity<Boolean> rejectOrder(@RequestBody OrderHistory user) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.rejectOrder(user));
	}
}
