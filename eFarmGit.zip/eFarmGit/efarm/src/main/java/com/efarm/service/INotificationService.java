package com.efarm.service;

import java.util.List;

import com.efarm.entity.Notifications;
import com.efarm.entity.OrderHistory;
import com.efarm.entity.Wallet;

public interface INotificationService {

	public boolean addNotification(Notifications user);
	public List<Notifications> getUserNotification(Long phoneNo);
	public List<Notifications> getAllNotifications();
	public boolean approveMoney(Wallet wallet);
	public boolean rejectMoney(Wallet user);
	public Wallet getWalletBalance(Long phoneNo);
	public boolean PlaceOrder(OrderHistory order);
	public List<OrderHistory> getAllOrdersList();
	public boolean sellOrder(OrderHistory order);
	public boolean rejectOrder(OrderHistory user);
	
}
