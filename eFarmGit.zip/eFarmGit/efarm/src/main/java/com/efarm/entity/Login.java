package com.efarm.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Login")
public class Login {


	@Id
	@Column(length=15)
	private long mobileNumber;
	@Column
	private String password;
	
	public Login() {
	}

	public Login(long mobileNumber, String password) {
		super();
		this.mobileNumber = mobileNumber;
		this.password = password;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobNum) {
		this.mobileNumber = mobNum;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Login [mobNum=" + mobileNumber + ", password=" + password + "]";
	}
	
}