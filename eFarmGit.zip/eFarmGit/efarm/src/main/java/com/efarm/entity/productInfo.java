package com.efarm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Product_Info")
public class productInfo {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long productId;
	@Column
	private long sellerId;

	@Column
	private String productName;
	@Column
	private String productType;
	@Column
	private String productDesc;
	@Column
	private int productQuantity;
	/*
	 * @Column private byte[] productImg;
	 */
	@Column
	private int productAvgRating;
	@Column
	private long productPrice;

	public long getSellerId() {
		return sellerId;
	}

	public void setSellerId(long sellerId) {
		this.sellerId = sellerId;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public void setProductPrice(long productPrice) {
		this.productPrice = productPrice;
	}
	
	
	public long getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Long productPrice) {
		this.productPrice = productPrice;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	/*
	 * public byte[] getProductImg() { return productImg; }
	 * 
	 * public void setProductImg(byte[] productImg) { this.productImg = productImg;
	 * }
	 */

	public int getProductAvgRating() {
		return productAvgRating;
	}

	public void setProductAvgRating(int productAvgRating) {
		this.productAvgRating = productAvgRating;
	}

	public productInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public productInfo(Long productId, String productName, String productType, String productDesc, int productAvgRating,
			Long productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productType = productType;
		this.productDesc = productDesc;
		// this.productImg = productImg;
		this.productAvgRating = productAvgRating;
		this.productPrice = productPrice;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productType=" + productType
				+ ", productDesc=" + productDesc + ", productImg=" + ", productAvgRating=" + productAvgRating
				+ ", productPrice=" + productPrice + "]";
	}

}
