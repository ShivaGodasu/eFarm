package com.efarm.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.efarm.entity.Login;
import com.efarm.service.ILoginService;


/**
 * @author Nikhil Garine
 *
 */
@RestController
@CrossOrigin(origins = {"http://localhost:4200"})
public class LoginController {

	@Autowired
	ILoginService service; 
	
	/**
	 * @param login
	 * @return boolean
	 * 
	 * returns true if the credentials are true
	 * else false
	 */
	
	@GetMapping(value = "/adminLogin", produces = "application/json")
	public boolean adminLogin(@RequestParam long phoneNo, String password) {
		Login login = new Login();
		login.setMobileNumber(phoneNo);
		login.setPassword(password);
		return service.login(login);
	}
	/**
	 * @param reg
	 * @return boolean
	 * 
	 * storing  admin credentials
	 */
	@PostMapping(value="/addAdmin" , consumes = "application/json")
	public boolean register(@RequestBody Login reg)
	{
		System.out.println("HII");
		return service.register(reg);
		
	} 
	
	/**
	 * @param mobile number
	 * @param current password
	 * @param new password
	 * @return boolean
	 * 
	 * change the password for admin
	 */
	@GetMapping(value="/changeAdminPassword/{mobNum}/{curPass}/{newPass}")
	public boolean changePassword(@PathVariable("mobNum") long mobNum,@PathVariable("curPass") String curPass,@PathVariable("newPass") String newPass)
	{ 
		return service.changePasword(mobNum, curPass, newPass);
		
	} 
	
	@GetMapping(value = "/sellerLogin", produces = "application/json")
	public boolean sellerLogin(@RequestParam long phoneNo, String password) {
		Login login = new Login();
		login.setMobileNumber(phoneNo);
		login.setPassword(password);
		return service.loginSeller(login);
	} 
	
}
