package com.efarm.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.efarm.dao.ILoginDao;
import com.efarm.entity.Login;

@Service
@Transactional
public class LoginServiceImpl implements ILoginService {

	@Autowired
	ILoginDao loginDao;

	@Override
	public boolean login(Login login) {
		boolean existedReg = loginDao.existsById(login.getMobileNumber());

		if (existedReg) {
			Login reg = loginDao.getOne(login.getMobileNumber());

			if (reg.getPassword().equals(login.getPassword())) {
				
				if(reg.getUserType().equals("Admin")) {
				return true;
				}
				else
					return false;
			}

			else
				return false;
		} else
			return false;

	}

	@Override
	public boolean register(Login login) {
		long phoneNo = login.getMobileNumber();
		boolean existedReg = loginDao.existsById(phoneNo);

		if (existedReg == false) {
			loginDao.save(login);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean changePasword(long mobNum, String curPass, String newPass) {
		boolean existedReg = loginDao.existsById(mobNum);
		if (existedReg) {
			Login login = loginDao.getOne(mobNum);
			if (login.getPassword().equals(curPass)) {
				login.setPassword(newPass);
				loginDao.save(login);
				return true;
			} else
				return false;
		} else {
			return false;
		}
	}

	@Override
	public boolean loginSeller(Login login) {
		boolean existedReg = loginDao.existsById(login.getMobileNumber());

		if (existedReg) {
			Login reg = loginDao.getOne(login.getMobileNumber());

			if (reg.getPassword().equals(login.getPassword())) {
				
				if(reg.getUserType().equals("Seller")) {
				return true;
				}
				else
					return false;
			}

			else
				return false;
		} else
			return false;
	}

}

