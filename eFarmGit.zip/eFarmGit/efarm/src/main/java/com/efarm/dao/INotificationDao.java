package com.efarm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.efarm.entity.Notifications;

@Repository
public interface INotificationDao extends JpaRepository<Notifications, Long> {

	List<Notifications> findAllByMobileNumber(long phoneNo);
	
}
