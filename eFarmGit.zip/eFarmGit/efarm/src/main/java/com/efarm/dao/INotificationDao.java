package com.efarm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.efarm.entity.Notifications;

public interface INotificationDao extends JpaRepository<Notifications, Long> {

	List<Notifications> findAllByMobileNumber(long phoneNo);
}
