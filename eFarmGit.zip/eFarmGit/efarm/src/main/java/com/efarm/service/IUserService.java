package com.efarm.service;

import com.efarm.entity.User;

public interface IUserService {
	public boolean register(User user);
	public boolean login(long phoneNo, String password);
	boolean setPassword(long phoneNo, String securityQuestion, String answer, String password);
	public User getUserName(Long phoneNo);
	public boolean editUser(User user);
	public boolean createSeller(Long phoneNo);
	
}
	