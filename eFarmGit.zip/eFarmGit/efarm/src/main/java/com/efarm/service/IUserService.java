package com.efarm.service;

import java.util.List;

import com.efarm.entity.Notifications;
import com.efarm.entity.User;

public interface IUserService {
	public boolean register(User user);
	public boolean login(long phoneNo, String password);
	boolean setPassword(long phoneNo, String securityQuestion, String answer, String password);
	public User getUserName(Long phoneNo);
	public boolean editUser(User user);
	public boolean addNotification(Notifications user);
	public List<Notifications> getUserNotification(Long phoneNo);

	
}
	