package com.efarm.service;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.efarm.dao.ILoginDao;
import com.efarm.dao.IUserDao;
import com.efarm.entity.Login;
import com.efarm.entity.User;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	IUserDao dao;
	@Autowired
	ILoginDao dao2;

	
	@Override
	public boolean register(User user) {
		long phoneNo = user.getMobileNumber();
		boolean existingUser = dao.existsById(phoneNo);

		if (existingUser) {
			return false;
		} else {

			user.setPassword(toEncode(user.getPassword()));
			dao.save(user);
			return true;

		}
	}

	public static String toEncode(String message) {
		return Base64.getEncoder().encodeToString(message.getBytes());
	}

	@Override
	public boolean login(long phoneNo, String password) {
		boolean existingUser = dao.existsById(phoneNo);

		if (existingUser) {
			User user = dao.getOne(phoneNo);
			String userPassword = toDecode(user.getPassword());

			if (userPassword.equals(password))
				return true;
			else
				return false;
		} else
			return false;

	}

	public static String toDecode(String message) {
		byte[] decodedBytes = Base64.getDecoder().decode(message);
		return new String(decodedBytes);
	}

	@Override
	public boolean setPassword(long phoneNo, String securityQuestion, String answer, String password) {
		boolean existingUser = dao.existsById(phoneNo);
		if (existingUser) {
			User user = dao.getOne(phoneNo);

			dao.save(user);
			return true;

		} else
			return false;

	}

	@Override
	public User getUserName(Long phoneNo) {
			User user = dao.findById(phoneNo).get();
			return user;
	}

	@Override
	public boolean editUser(User user) {
		long phoneNo = user.getMobileNumber();
		boolean existingUser = dao.existsById(phoneNo);

		if (existingUser) {
			User olduser = dao.getOne(phoneNo);
			user.setPassword(olduser.getPassword());
			dao.save(user);
			return true;

		} else
			return false;
	}

	@Override
	public boolean createSeller(Long phoneNo) {
		Login log = new Login();
		log.setMobileNumber(phoneNo);
		User user = new User();
		user = dao.getOne(phoneNo);
		log.setPassword(toDecode(user.getPassword()));
		log.setUserType("Seller");
		dao2.save(log);
		
		return true;
	}

}
