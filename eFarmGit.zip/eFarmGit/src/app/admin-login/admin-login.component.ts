import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CapService } from '../cap.service';
import { Login } from '../Model/Login';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  
  message: string;
  status: Boolean;
  
  constructor(private capService: CapService, private router: Router, private toastr: ToastrService) { }

  login: Login = new Login();
  ngOnInit(): void {
  }
  onSubmit(userForm) {
    this.capService.loginUser(userForm).subscribe((data: boolean) => {
      if (data) {
        sessionStorage.setItem('username', this.login.mobNum + "");
        sessionStorage.setItem('userType', 'Admin');
        this.toastr.success('Logged in Successfully', 'Admin');

        this.router.navigate(['/adminHome']);
      }
      
      else {
this.message="Invalid Credentials!";      
}
    },
      error => console.log(error)
    );

  }




}
