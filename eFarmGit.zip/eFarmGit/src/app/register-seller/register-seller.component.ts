import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-seller',
  templateUrl: './register-seller.component.html',
  styleUrls: ['./register-seller.component.css']
})
export class RegisterSellerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
