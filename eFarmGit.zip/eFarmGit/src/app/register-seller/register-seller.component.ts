import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapService } from '../cap.service';

@Component({
  selector: 'app-register-seller',
  templateUrl: './register-seller.component.html',
  styleUrls: ['./register-seller.component.css']
})
export class RegisterSellerComponent implements OnInit {

  constructor(private service:CapService, private router:Router) { }

  ngOnInit(): void {
  }

  createSeller(){
    this.service.createSeller().subscribe(data => {
      if(data){
      alert("Seller Account created");
      this.router.navigate(['/mainHome']);
      }else
      alert("Unable to create as seller");
    }
      )
  }
}
