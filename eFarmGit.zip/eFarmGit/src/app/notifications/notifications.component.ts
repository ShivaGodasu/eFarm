import { Component, OnInit } from '@angular/core';
import { CapService } from '../cap.service';
import { orderHistory } from '../Model/OrderHistory';
import { User } from '../Model/User';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  constructor(private serivce:CapService) { }

  notificationList;
  addMoneyNotificationsList;
  ordersList;
  user:User=new User();
  ngOnInit(): void {

    this.serivce.getUserName().subscribe(data=>
      this.user=data
      );
    
    this.serivce.getAllNotificationsList().subscribe( (data:any)=>{
      this.notificationList=data;
      console.log(data);

      this.addMoneyNotificationsList  = this.notificationList.filter(value=>value.notificationType == "addMoney");
      console.log(this.addMoneyNotificationsList);
     });     

    this.serivce.getAllOrdersList().subscribe( (data:orderHistory)=>{
      this.ordersList=data;
      console.log(data)
      this.ordersList = this.ordersList.filter(value => value.status == "SellerApproval")
      console.log("Hiiiiiiiiiiiiiiiiiii"+this.ordersList);
     });
  }

  
  addMoney(number,amount){
    console.log(number,amount);
    this.serivce.approveMoney(number,amount).subscribe( data=>
      {
        if(data){
          alert("Amount added");
        }else{
          alert("Unable to add");
        }
      })
  }

  rejectMoney(number,amount){
    console.log(number,amount);
    this.serivce.rejectMoney(number,amount).subscribe( data=>
      {
        if(data){
          alert("sent rejection notification to user");
        }else{
          alert("Unable to send notification to user");
        }
      })
  }

  sellOrder(order){
    this.serivce.sellOrder(order).subscribe( data=>
      {
        if(data){
          alert("Order completed");
        }else{
          alert("Unable to complete order");
        }
      })


  }
  rejectOrder(order){

    this.serivce.rejectOrder(order).subscribe( data=>
      {
        if(data){
          alert("Order cancelled");
        }else{
          alert("Unable to cancel order");
        }
      })
  }

  logout(){
    this.serivce.logout();
  }

}
