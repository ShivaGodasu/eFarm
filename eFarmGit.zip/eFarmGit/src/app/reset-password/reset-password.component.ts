import { Component, OnInit } from '@angular/core';
import { CapService } from '../cap.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  status:Boolean;
  message:string;
  constructor(private capService:CapService,private router:Router) { }
  onSubmit(resetPasswordForm:any){
    
    
    }
  

 

  ngOnInit(): void {
  }
 
}
