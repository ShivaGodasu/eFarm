import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapService } from '../cap.service';
import { orderHistory } from '../Model/OrderHistory';
import { User } from '../Model/User';

@Component({
  selector: 'app-seller-orders',
  templateUrl: './seller-orders.component.html',
  styleUrls: ['./seller-orders.component.css']
})
export class SellerOrdersComponent implements OnInit {


  constructor(private serivce:CapService, private router:Router) { }

  notificationList;
  addMoneyNotificationsList;
  ordersList;
 
  user:User=new User();
  ngOnInit(): void {
    this.serivce.getUserName().subscribe(data=>
      this.user=data
      )
    this.serivce.getAllOrdersList().subscribe( (data:orderHistory)=>{
      this.ordersList=data;
      console.log(this.ordersList);
      this.ordersList = this.ordersList.filter(value => value.sellerId==localStorage.getItem("mobile"));
      this.ordersList = this.ordersList.sort(function(a,b){
       return b.orderId - a.orderId
      })
     });
  }
  getProductById(id:Number):void{
    this.router.navigate(['/product',id]);
  }

  logout(){
    this.serivce.logout();
  }
}
