import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CapService } from '../cap.service';
import { User } from '../Model/User';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  constructor(private service: CapService, private route: ActivatedRoute, private router: Router, private toastr: ToastrService) { }

  id;
  product;
  status;
  message;
  user: User = new User();

  ngOnInit() {
    this.service.getUserName().subscribe(data =>
      this.user = data
    )
    this.id = Number(this.route.snapshot.paramMap.get('Id'));
    this.service.getProductById(this.id).subscribe((productData: any) => { this.product = productData, console.log(productData) }, error => console.log(error));
  }

  onSubmit(userForm: any) {
    console.log(userForm)
    this.service.editProduct(userForm, this.product.productId, this.product.rating).subscribe((data: Boolean) => {
      this.status = data;
      if (this.status) {
        console.log(this.status);
        alert("Edited Successfully...")
        this.message = "Edited Successfully..."
        this.toastr.success('Edited Successfully', 'Product');
        this.router.navigate(['/sellerHome']);
      }
      else {
        this.message = "Unable to edit";
        alert("Unable to edit");
        console.log(this.status);
        this.router.navigate(['/sellerHome']);

      }
    });

  }

  logout() {
    this.service.logout();
  }
}
