import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import bootstrap from "bootstrap";

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
//import * as firebase from 'firebase';
import { ToastrModule} from 'ngx-toastr';

import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AppHomeNavComponent } from './app-home-nav/app-home-nav.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { UserNavbarComponent } from './user-navbar/user-navbar.component';
import { UserFooterComponent } from './user-footer/user-footer.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductComponent } from './product/product.component';
import { CapService } from './cap.service';
import { AddProductComponent } from './add-product/add-product.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import { PaymentSummaryComponent } from './payment-summary/payment-summary.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { RegisterSellerComponent } from './register-seller/register-seller.component';
import { MainHomeComponent } from './main-home/main-home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { CartComponent } from './cart/cart.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { NotificationsComponent } from './notifications/notifications.component';


@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    UserRegistrationComponent,
    ResetPasswordComponent,
    ForgotPasswordComponent,
    AppHomeNavComponent,
    UserHomeComponent,
    UserNavbarComponent,
    UserFooterComponent,
    ProductListComponent,
    ProductComponent,
    AddProductComponent,
    OrderSummaryComponent,
    PaymentSummaryComponent,
    UserProfileComponent,
    OrderHistoryComponent,
    EditProfileComponent,
    RegisterSellerComponent,
    MainHomeComponent,
    AdminLoginComponent,
    CartComponent,
    AdminHomeComponent,
    NotificationsComponent
  ],
  imports: [
    
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    CommonModule,
    Ng2SearchPipeModule,
    ToastrModule.forRoot({
      timeOut: 9000,
      positionClass: 'toast-top-right',
      preventDuplicates: false,
    })
  ],
  providers: [CapService],
  bootstrap: [AppComponent]
})
export class AppModule { }
