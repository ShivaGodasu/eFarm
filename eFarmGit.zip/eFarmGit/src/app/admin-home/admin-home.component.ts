import { Component, OnInit } from '@angular/core';
import { CapService } from '../cap.service';
import { Router } from '@angular/router';
import { User } from '../Model/User';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {


  constructor(private service:CapService,private router:Router) { }

  user:User=new User();

  ngOnInit(): void {
   this.service.getUserName().subscribe(data=>
    this.user=data
    )
  }

  userProfile(id){
    this.router.navigate(['userProfile',id]);
  }

  createSeller(id){
    this.router.navigate(['createSeller',id]);
  }


  orderHistory(id){
    this.router.navigate(['orderHistory',id]);
  }

  logout(){
    this.service.logout();
  }

}
