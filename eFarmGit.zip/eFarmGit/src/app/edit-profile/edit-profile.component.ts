import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CapService } from '../cap.service';
import { User } from '../Model/User';


@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

  id:number;
  user:User=new User();
  status:any;
  message:string = "hiijkers";
  constructor(private _service: CapService,private route: ActivatedRoute,private router:Router,private toastr:ToastrService) { }

  ngOnInit() {
    this.id = Number(this.route.snapshot.paramMap.get('Id'));
    this._service.getUserName().subscribe(data=>
      this.user=data
      )
  }

  onSubmit(userForm:any){
    console.log(userForm)
    this._service.editUser(userForm).subscribe((data:Boolean)=>{
      this.status=data;
      if(this.status){
      console.log(this.status);
      this.message="Edited Successfully..."
      this.toastr.success('Edited Successfully', 'User');
      this.router.navigate(['/userProfile',this.id]);
      }
      else{
        this.message="Unable to edit";
        alert("Unable to edit");
        console.log(this.status);
        this.router.navigate(['/userProfile',this.id]);

      }
    });

}
}
