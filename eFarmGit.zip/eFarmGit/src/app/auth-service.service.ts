import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {


  constructor(private router: Router) {
  }


  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    return (!(user === null))
  }

  isAdminLoggedIn() {
    let user = sessionStorage.getItem('username')
    let type = sessionStorage.getItem('userType')
    return (!(user === null) && type === 'Admin')
  }

  isSellerLoggedIn() {
    let user = sessionStorage.getItem('username')
    let type = sessionStorage.getItem('userType')
    return (!(user === null) && type === 'Seller')
  }
  logOut() {
    sessionStorage.removeItem('username')
    sessionStorage.removeItem('userType')
  }


}
