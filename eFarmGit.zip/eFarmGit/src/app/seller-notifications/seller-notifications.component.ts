import { Component, OnInit } from '@angular/core';
import { CapService } from '../cap.service';
import { orderHistory } from '../Model/OrderHistory';
import { User } from '../Model/User';

@Component({
  selector: 'app-seller-notifications',
  templateUrl: './seller-notifications.component.html',
  styleUrls: ['./seller-notifications.component.css']
})
export class SellerNotificationsComponent implements OnInit {

 
  constructor(private serivce:CapService) { }

  notificationList;
  addMoneyNotificationsList;
  ordersList;
  user:User=new User();
  ngOnInit(): void {

    this.serivce.getUserName().subscribe(data=>
      this.user=data
      ); 

    this.serivce.getAllOrdersList().subscribe( (data:orderHistory)=>{
      this.ordersList=data;
      console.log(data)
      this.ordersList = this.ordersList.filter(value => (value.status == "SellerApproval")&&(value.sellerId==localStorage.getItem("mobile")))
      console.log(this.ordersList);
      console.log(localStorage.getItem('mobile'))
     });
  }

  sellOrder(order){
    this.serivce.sellOrder(order).subscribe( data=>
      {
        if(data){
          alert("Order completed");
        }else{
          alert("Unable to complete order");
        }
      })


  }
  rejectOrder(order){

    this.serivce.rejectOrder(order).subscribe( data=>
      {
        if(data){
          alert("Order cancelled");
        }else{
          alert("Unable to cancel order");
        }
      })
  }

  logout(){
    this.serivce.logout();
  }

}
