import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-nav',
  templateUrl: './app-home-nav.component.html',
  styleUrls: ['./app-home-nav.component.css']
})
export class AppHomeNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
