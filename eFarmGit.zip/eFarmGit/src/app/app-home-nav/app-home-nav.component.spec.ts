import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppHomeNavComponent } from './app-home-nav.component';

describe('AppHomeNavComponent', () => {
  let component: AppHomeNavComponent;
  let fixture: ComponentFixture<AppHomeNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppHomeNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppHomeNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
