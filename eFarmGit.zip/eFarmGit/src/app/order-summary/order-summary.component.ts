import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapService } from '../cap.service';
import { Product } from '../Model/Product_Info';
import { User } from '../Model/User';

@Component({
  selector: 'app-order-summary',
  templateUrl: './order-summary.component.html',
  styleUrls: ['./order-summary.component.css']
})
export class OrderSummaryComponent implements OnInit {

  id:number;
  Quantity : number[] = [1,2,3];
  product:Product = new Product();
  user:User=new User();
  constructor(private _service: CapService,private route: ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.id = Number(this.route.snapshot.paramMap.get('Id'));
    this._service.getProductById(this.id).subscribe(
      (productData: any) => { 
        this.product = productData, 
        console.log(productData) }, error => console.log(error));
    this._service.getUserName().subscribe(data=>
      this.user=data
      )
  }

  payment(){
    this.router.navigate(['/payment',this.id]);
  }
}
