export class Feedback{

    userId:number;
    productId:number;
    feedback:String;
    rating:number;
}