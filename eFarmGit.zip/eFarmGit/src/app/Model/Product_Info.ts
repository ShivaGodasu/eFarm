export class Product
{
    productId:number;
    sellerId:number;
    productName:string;
    productType:string;
    productPrice:number;
    productDesc:string;
    productQuantity:number;
  //  productImg:File;
    productAvgRating:number;
    
}