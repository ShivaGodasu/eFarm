export interface Wallet{
    mobileNumber:string;
    walletBalance:number;
}