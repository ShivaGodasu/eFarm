export interface orderHistory {
    orderId:number;
    sellerId:number;
    customerId:number;
    productId:number;
    productName:string;
    quantity:number;
    cost:number;
    status:string;
}