export class User{
	mobileNumber:Number
	name:string
	address:String
    password:String
	
}