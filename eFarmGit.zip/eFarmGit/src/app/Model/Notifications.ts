export class Notification{
    notificationId:number;
    mobileNumber:number;
    notificationType:string;
    content:string;
    amount:number;
}