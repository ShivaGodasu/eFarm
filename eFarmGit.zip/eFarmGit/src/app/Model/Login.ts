export class Login{
  
    mobNum:number
    password:string

}