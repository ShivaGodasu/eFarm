import { Component, OnInit } from '@angular/core';
import { CapService } from '../cap.service';

@Component({
  selector: 'app-user-notifications',
  templateUrl: './user-notifications.component.html',
  styleUrls: ['./user-notifications.component.css']
})
export class UserNotificationsComponent implements OnInit {

  notificationList;
  user;
  constructor(private serivce:CapService) { }


  ngOnInit(){
    this.serivce.getUserName().subscribe(data=>
      this.user=data
      );
    
    this.serivce.getAllNotificationsList().subscribe( (data:any)=>{
      this.notificationList=data;
      console.log(data);
  
      this.notificationList = this.notificationList.filter(value=>(value.mobileNumber == localStorage.getItem('mobile'))&&(value.notificationType != "addMoney"));
      this.notificationList = this.notificationList.sort(function(a,b){
        return b.notificationId-a.notificationId
      })
      console.log(this.notificationList);
     }); 
  }

    

}
