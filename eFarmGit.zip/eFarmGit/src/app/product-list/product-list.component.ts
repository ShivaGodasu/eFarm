import { Component, OnInit } from '@angular/core';
import {  Product } from '../Model/Product_Info';
import { Range } from '../Model/range';
import { CapService } from '../cap.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  
product=new Product();
productList:Product[];
productId:number;
type:string="All";
range = new Range();
searchText:any;

  constructor(private _service:CapService, private router:Router) { }

  ngOnInit() {
   this._service.getAllProdcutsList().subscribe(
     (data:any)=>{
     this.productList=data;
     console.log(data);
    });
  }

//*********************************************** Product Page Module ************************************************ */

  getProducts(type:string):void{
    this._service.getProducts(this.product.productType).subscribe((productData:any)=>{this.productList=productData,console.log(productData)},error=>console.log(error));
    this.type=this.product.productType;
  }
  getProductById(id:Number):void{
    
    this.router.navigate(['/product',id]);

  }
//************************************* Sorting Module*************************************************//


  sortByAssending(){     
       this.productList=this.productList.sort(function(a,b){
        return a.productPrice-b.productPrice;
       })
  }
  sortByDescending(){
    this.productList=this.productList.sort(function(a,b){
         return b.productPrice-a.productPrice;
    })
  }
  sortByRange(low:number,high:number){
    console.log(low,high);
    this._service.getProductListByRange(low,high,this.type).subscribe(data=>this.productList=data);
  }
  sortByBestSeller(){
    this.productList=this.productList.sort(function(a,b){
      return a.productAvgRating-b.productAvgRating;
    })
  }
  sortByViews(){
    this.productList=this.productList.sort(function(a,b){
      return a.productAvgRating-b.productAvgRating;
    })
  }


  
/////////////////////////////////////////////////////////
  getWishList(userId:number){
    this._service.getWishlist(userId).subscribe((productData:any)=>{this.productList=productData,console.log(productData)},error=>console.log(error));
  }
}
