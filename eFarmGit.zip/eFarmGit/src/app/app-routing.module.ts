import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductComponent } from './product/product.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import { PaymentSummaryComponent } from './payment-summary/payment-summary.component';
import { AuthGuardService } from './auth-guard.service';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { MainHomeComponent } from './main-home/main-home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';

const routes: Routes = [
  { path: '', redirectTo: 'mainHome', pathMatch: 'full' },
  { path: 'register', component: UserRegistrationComponent },
  { path: 'forgotPassword', component: ForgotPasswordComponent },
  { path: 'resetPassword', component: ResetPasswordComponent },
  { path: 'login', component: UserLoginComponent },
  { path: 'adminLogin', component: AdminLoginComponent },
  { path: 'adminHome', component: AdminHomeComponent },
  { path: 'mainHome', component: MainHomeComponent },
  { path: 'list', component: ProductListComponent },
  { path: 'product/:Id', component: ProductComponent },
  { path: 'addProduct', component: AddProductComponent, canActivate: [AuthGuardService] },
  { path: 'userProfile/:Id', component: UserProfileComponent , canActivate: [AuthGuardService]},
  { path: 'editProfile/:Id', component: EditProfileComponent , canActivate: [AuthGuardService]},
  { path: 'userHome', component: UserHomeComponent, canActivate: [AuthGuardService] },
  { path: 'buyNow/:Id', component: OrderSummaryComponent, canActivate: [AuthGuardService] },
  { path: 'payment/:Id', component: PaymentSummaryComponent, canActivate: [AuthGuardService] },
  { path: 'orderHistory/:Id', component: OrderHistoryComponent, canActivate: [AuthGuardService] }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
