import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductComponent } from './product/product.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import { PaymentSummaryComponent } from './payment-summary/payment-summary.component';
import { AuthGuardService } from './auth-guard.service';
import { AdminGuardService } from './admin-guard.service';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { MainHomeComponent } from './main-home/main-home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { UserNotificationsComponent } from './user-notifications/user-notifications.component';
import { AuthServiceService } from './auth-service.service';
import { SellerLoginComponent } from './seller-login/seller-login.component';
import { SellerNotificationsComponent } from './seller-notifications/seller-notifications.component';
import { SellerHomeComponent } from './seller-home/seller-home.component';
import { RegisterSellerComponent } from './register-seller/register-seller.component';
import { SellerOrdersComponent } from './seller-orders/seller-orders.component';
import { SellerProductsComponent } from './seller-products/seller-products.component';
import { EditProductComponent } from './edit-product/edit-product.component';

const routes: Routes = [
  { path: '', redirectTo: 'mainHome', pathMatch: 'full' },
  { path: 'register', component: UserRegistrationComponent },
  { path: 'forgotPassword', component: ForgotPasswordComponent },
  { path: 'resetPassword', component: ResetPasswordComponent },
  { path: 'login', component: UserLoginComponent },
  { path: 'adminLogin', component: AdminLoginComponent },
  { path: 'adminHome', component: AdminHomeComponent, canActivate: [AdminGuardService] },
  { path: 'mainHome', component: MainHomeComponent },
  { path: 'list', component: ProductListComponent },
  { path: 'product/:Id', component: ProductComponent },
  { path: 'addProduct', component: AddProductComponent, canActivate: [AuthGuardService] },
  { path: 'userProfile/:Id', component: UserProfileComponent , canActivate: [AuthGuardService]},
  { path: 'editProfile/:Id', component: EditProfileComponent , canActivate: [AuthGuardService]},
  { path: 'userHome', component: UserHomeComponent, canActivate: [AuthGuardService] },
  { path: 'buyNow/:Id', component: OrderSummaryComponent, canActivate: [AuthGuardService] },
  { path: 'payment/:Id/:selectQty', component: PaymentSummaryComponent, canActivate: [AuthGuardService] },
  { path: 'orderHistory/:Id', component: OrderHistoryComponent, canActivate: [AuthGuardService] },
  { path: 'notifications', component: NotificationsComponent, canActivate: [AdminGuardService] },
  { path: 'userNotifications', component: UserNotificationsComponent , canActivate: [AuthGuardService] },
  { path: 'sellerLogin', component: SellerLoginComponent },
  { path: 'sellerHome', component: SellerHomeComponent , canActivate: [AuthGuardService] },
  { path: 'sellerNotifications', component: SellerNotificationsComponent , canActivate: [AuthGuardService] },
  { path: 'registerSeller', component: RegisterSellerComponent , canActivate: [AuthGuardService] },
  { path: 'sellerOrders', component: SellerOrdersComponent , canActivate: [AuthGuardService] },
  { path: 'sellerProducts', component: SellerProductsComponent , canActivate: [AuthGuardService] },
  { path: 'editProduct/:Id', component: EditProductComponent , canActivate: [AuthGuardService] }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
