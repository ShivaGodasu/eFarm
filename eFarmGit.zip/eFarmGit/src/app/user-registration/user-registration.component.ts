import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { CapService } from '../cap.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {

  status:Boolean;
  message:string;
  constructor(private capService:CapService,private router:Router,private toastr:ToastrService) { }
  
  onSubmit(registationForm:any){
    
      this.capService.register(registationForm).subscribe((data:Boolean)=>{
        this.status=data;
        if(this.status){
        console.log(this.status);
        this.message="Registered Successfully..."
        this.toastr.success('Registered Successfully', 'User');
        alert(this.message);
        this.router.navigate(['/login']);
        }
        else{
          this.message="User is alredy existing";
          alert("User already exist");
          console.log(this.status);
          this.router.navigate(['/login']);

        }
      });

  }
 

  ngOnInit(): void {
  }

}
