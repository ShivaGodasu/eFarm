import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapService } from '../cap.service';
import { Product } from '../Model/Product_Info';
import { User } from '../Model/User';

@Component({
  selector: 'app-seller-products',
  templateUrl: './seller-products.component.html',
  styleUrls: ['./seller-products.component.css']
})
export class SellerProductsComponent implements OnInit {

  constructor(private service:CapService,private router:Router) { }

  productsList;
  user:User=new User();
  ngOnInit(): void {
    this.service.getUserName().subscribe(data=>
      this.user=data
      )
    this.service.getAllProdcutsList().subscribe(data=>{
      this.productsList = data;
      this.productsList = this.productsList.filter(value=> value.sellerId == localStorage.getItem('mobile'));
    })
  }
  Edit(product:Product){
    this.router.navigate(['/editProduct',product.productId]);
  }

  logout(){
    this.service.logout();
  }
}
