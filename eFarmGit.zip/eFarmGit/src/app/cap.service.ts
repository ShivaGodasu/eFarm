import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BehaviorSubject, Observable } from 'rxjs';
import { UserLoginComponent } from './user-login/user-login.component';
import { Product } from './Model/Product_Info';
import { Login } from './Model/Login';

@Injectable({
  providedIn: 'root'
})
export class CapService {

  phoneNo: any;
  contact: any;
  newcontact: Number;
  user: any;
  securityQuestion: any;
  answer: any;
  message: string;
  status: boolean;
  pId: Number;
  

  private baseUrl = 'http://localhost:8080/';


  constructor(private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  login(login: Login): Observable<any> {
    console.log(login);
    this.phoneNo = login.mobNum;
    let password = login.password;
    localStorage.setItem("mobile", this.phoneNo);
  
    return this.http.get(`${this.baseUrl}` + "/adminLogin?phoneNo=" + this.phoneNo + "&password=" + password);

  }

  register(user: any) {
    console.log(user);
    let input = {
      "mobileNumber": user.mobileNumber,
      "name": user.name,
      "address": user.address,
      "password": user.password
    }
    return this.http.post(`${this.baseUrl}` + `/register`, input);
  }


  loginUser(userCredentials: any) {
    this.phoneNo = userCredentials.phone;
    let password = userCredentials.password;
    localStorage.setItem("mobile", this.phoneNo);
    return this.http.get(`${this.baseUrl}` + "/login?phoneNo=" + this.phoneNo + "&password=" + password);
  }

  getUserName(): any {
    this.contact = localStorage.getItem("mobile");
    this.newcontact = parseInt(this.contact);
    console.log(this.newcontact);
    return this.http.get(`${this.baseUrl}` + "/getUserName?phoneNo=" + this.newcontact)
  }

  logout() {
    sessionStorage.removeItem('username')
    sessionStorage.removeItem('user')
    sessionStorage.removeItem('userType')
    sessionStorage.clear();
    this.router.navigate(['/login'])
  }

  getUserNotification(){
    this.contact = localStorage.getItem("mobile");
    return this.http.get(`${this.baseUrl}` + "/getUserNotification?phoneNo=" + this.newcontact);
  }

  addMoney(wallet: any) {
    this.phoneNo = wallet.amount;
    console.log(this.phoneNo)
    return this.http.post(`${this.baseUrl}` + `/addMoney`, this.phoneNo);
  }

  product: Product[];
  private userId = new BehaviorSubject<number>(0);
  currentUser = this.userId.asObservable();

  getProducts(type: string) {
    return this.http.get(`${this.baseUrl}` + type);
  }
  getProductById(id: number) {

    this.pId = Number(id);

    return this.http.get(`${this.baseUrl}` + `/ProductById/` + this.pId);
  }

  editUser(user: any) {

    let input = {
      "mobileNumber": localStorage.getItem("mobile"),
      "name": user.name,
      "address": user.address

    }
    return this.http.post(`${this.baseUrl}` + `/editUser`, input);
  }



  addProduct(productInfo: Product) {

    let input = {
      "productId": 0,
      "sellerId": localStorage.getItem("mobile"),
      "productName": productInfo.productName,
      "productType": productInfo.productType,
      "productPrice": productInfo.productPrice,
      "productDesc": productInfo.productDesc,
      "productQuantity": productInfo.productQuantity,
      //  productImg:File;
      "productAvgRating": 0
    }
    console.log(input);
    return this.http.post(`${this.baseUrl}` + `/addProduct`, input);
  }


  getFeedbackById(id: number) {
    return this.http.get("//localhost:8090/FeedbackById/" + id);
  }

  getProductListByRange(low: number, high: number, type: string): Observable<any> {
    return this.http.get("http://localhost:8090/get/" + low + "/" + high + "/" + type);
  }

  getAllProdcutsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + "/getAllProducts");
  }

  addtoWishList(productId, userId): Observable<any> {
    let body = JSON.stringify(productId);
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post("http://localhost:8090/addtoWishList/" + userId + "/", body, { headers: headers });
  }

  getWishlist(userId): Observable<any> {
    return this.http.get("//localhost:8090/getWishList/" + userId);
  }

  addtoCart(productId, userId1): Observable<any> {
    let body = JSON.stringify(productId);
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post("http://localhost:8090/addtoCart/" + userId1 + "/", body, { headers: headers });
  }
}
