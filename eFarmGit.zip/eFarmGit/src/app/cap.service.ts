import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BehaviorSubject, Observable } from 'rxjs';
import { Product } from './Model/Product_Info';
import { Login } from './Model/Login';
import { orderHistory } from './Model/OrderHistory'

@Injectable({
  providedIn: 'root'
})
export class CapService {

  phoneNo: any;
  contact: any;
  newcontact: Number;
  user: any;
  securityQuestion: any;
  answer: any;
  message: string;
  status: boolean;
  pId: Number;


  private baseUrl = 'http://localhost:8080/';


  constructor(private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  login(login: Login): Observable<any> {
    console.log(login);
    this.phoneNo = login.mobNum;
    let password = login.password;
    localStorage.setItem("mobile", this.phoneNo);

    return this.http.get(`${this.baseUrl}` + "/adminLogin?phoneNo=" + this.phoneNo + "&password=" + password);

  }

  register(user: any) {
    console.log(user);
    let input = {
      "mobileNumber": user.mobileNumber,
      "name": user.name,
      "address": user.address,
      "password": user.password
    }
    return this.http.post(`${this.baseUrl}` + `/register`, input);
  }


  loginUser(userCredentials: any) {
    this.phoneNo = userCredentials.phone;
    let password = userCredentials.password;
    localStorage.setItem("mobile", this.phoneNo);
    return this.http.get(`${this.baseUrl}` + "/login?phoneNo=" + this.phoneNo + "&password=" + password);
  }

  loginSeller(userCredentials: any) {
    this.phoneNo = userCredentials.phone;
    let password = userCredentials.password;
    localStorage.setItem("mobile", this.phoneNo);
    return this.http.get(`${this.baseUrl}` + "/sellerLogin?phoneNo=" + this.phoneNo + "&password=" + password);
  }
  getUserName(): any {
    this.contact = localStorage.getItem("mobile");
    this.newcontact = parseInt(this.contact);
    console.log(this.newcontact);
    return this.http.get(`${this.baseUrl}` + "/getUserName?phoneNo=" + this.newcontact)
  }

  logout() {
    sessionStorage.removeItem('username')
    sessionStorage.removeItem('user')
    sessionStorage.removeItem('userType')
    sessionStorage.clear();
    this.router.navigate(['/mainHome'])
  }

  getUserNotification() {
    this.contact = localStorage.getItem("mobile");
    return this.http.get(`${this.baseUrl}` + "/getUserNotification?phoneNo=" + this.newcontact);
  }

  getAllNotificationsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + "/getAllNotifications");
  }

  getAllOrdersList(): Observable<any> {

    return this.http.get(`${this.baseUrl}` + "/getAllOrdersList");

  }


  getWalletBalance() {
    this.contact = localStorage.getItem("mobile");
    return this.http.get(`${this.baseUrl}` + "/getWalletBalance?phoneNo=" + this.newcontact);
  }
  addMoney(wallet: any) {

    let input = {
      "mobileNumber": localStorage.getItem("mobile"),
      "notificationType": "addMoney",
      "content": "add Money request is sent to admin",
      "amount": wallet.amount
    }
    return this.http.post(`${this.baseUrl}` + `/addMoney`, input);
  }

  approveMoney(number, money) {
    let input = {
      "mobileNumber": number,
      "walletBalance": money
    }

    return this.http.post(`${this.baseUrl}` + `/approveMoney`, input);
  }

  rejectMoney(number, money) {
    let input = {
      "mobileNumber": number,
      "walletBalance": money
    }

    return this.http.post(`${this.baseUrl}` + `/rejectMoney`, input);
  }

  sellOrder(order: orderHistory) {

    return this.http.post(`${this.baseUrl}` + `/sellOrder`, order);

  }

  rejectOrder(order: orderHistory) {

    return this.http.post(`${this.baseUrl}` + `/rejectOrder`, order);
  }




  placeOrder(sellerId, id, name, selectQty, cost) {
    let input = {
      "sellerId": sellerId,
      "customerId": localStorage.getItem("mobile"),
      "productId": id,
      "productName": name,
      "quantity": selectQty,
      "cost": cost,
      "status": "SellerApproval"
    }

    return this.http.post(`${this.baseUrl}` + `/placeOrder`, input);
  }

  product: Product[];
  private userId = new BehaviorSubject<number>(0);
  currentUser = this.userId.asObservable();

  getProducts(type: string) {
    return this.http.get(`${this.baseUrl}` + type);
  }
  getProductById(id: number) {

    this.pId = Number(id);

    return this.http.get(`${this.baseUrl}` + `/ProductById/` + this.pId);
  }

  editUser(user: any) {

    let input = {
      "mobileNumber": localStorage.getItem("mobile"),
      "name": user.name,
      "address": user.address

    }
    return this.http.post(`${this.baseUrl}` + `/editUser`, input);
  }

  createSeller() {
    this.contact = localStorage.getItem("mobile");
    this.newcontact = parseInt(this.contact);
    return this.http.get(`${this.baseUrl}` + "/createSeller?phoneNo=" + this.newcontact);
  }

  addProduct(productInfo: Product) {

    let input = {
      "productId": 0,
      "sellerId": localStorage.getItem("mobile"),
      "productName": productInfo.productName,
      "productType": productInfo.productType,
      "productPrice": productInfo.productPrice,
      "productDesc": productInfo.productDesc,
      "productQuantity": productInfo.productQuantity,
      //  productImg:File;
      "productAvgRating": 0
    }
    console.log(input);
    return this.http.post(`${this.baseUrl}` + `/addProduct`, input);
  }

  editProduct(productInfo: Product, id, rating) {

    let input = {
      "productId": id,
      "sellerId": localStorage.getItem("mobile"),
      "productName": productInfo.productName,
      "productType": productInfo.productType,
      "productPrice": productInfo.productPrice,
      "productDesc": productInfo.productDesc,
      "productQuantity": productInfo.productQuantity,
      "productAvgRating": rating
    }
    console.log(input);
    return this.http.post(`${this.baseUrl}` + `/editProduct`, input);
  }


  getFeedbackById(id: number) {
    return this.http.get("//localhost:8090/FeedbackById/" + id);
  }

  getProductListByRange(low: number, high: number, type: string): Observable<any> {
    return this.http.get("http://localhost:8090/get/" + low + "/" + high + "/" + type);
  }

  getAllProdcutsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + "/getAllProducts");
  }

  addtoWishList(productId, userId): Observable<any> {
    let body = JSON.stringify(productId);
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post("http://localhost:8090/addtoWishList/" + userId + "/", body, { headers: headers });
  }

  getWishlist(userId): Observable<any> {
    return this.http.get("//localhost:8090/getWishList/" + userId);
  }

  addtoCart(productId, userId1): Observable<any> {
    let body = JSON.stringify(productId);
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post("http://localhost:8090/addtoCart/" + userId1 + "/", body, { headers: headers });
  }
}
