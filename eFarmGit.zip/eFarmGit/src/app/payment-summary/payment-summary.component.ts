import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapService } from '../cap.service';
import { Product } from '../Model/Product_Info';
import { User } from '../Model/User';
import { Wallet } from '../Model/Wallet'

@Component({
  selector: 'app-payment-summary',
  templateUrl: './payment-summary.component.html',
  styleUrls: ['./payment-summary.component.css']
})
export class PaymentSummaryComponent implements OnInit {

  id: number;
  product: Product = new Product();
  curwalletBalance: number;
  user: User = new User();
  selectQty: number;
  cost: number;
  constructor(private _service: CapService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.id = Number(this.route.snapshot.paramMap.get('Id'));
    this.selectQty = Number(this.route.snapshot.paramMap.get('selectQty'));

    this._service.getProductById(this.id).subscribe(
      (productData: any) => {
        this.product = productData,
          this.cost = this.selectQty * this.product.productPrice;
        console.log(productData)
      }, error => console.log(error));
    this._service.getUserName().subscribe(data =>
      this.user = data
    );
    this._service.getWalletBalance().subscribe((data: Wallet) => {

      if (data != null) {
        this.curwalletBalance = data.walletBalance;
      }
      else {
        this.curwalletBalance = 0;
      }
    });
  }


  placeOrder() {

    if(this.curwalletBalance<this.cost){
      alert("Insufficient Balance\n Current Balance : "+ this.curwalletBalance)
    }else{
      this._service.placeOrder(this.product.sellerId,this.id,this.product.productName,this.selectQty,this.cost).subscribe((data:boolean) =>{
        if(data){
          alert("Order Placed \n Went for Seller approval");
        }
        else{
          alert("Unable to Place the order");
        }
      }

      )
    }

  }

  cancel() {
    this.router.navigate(['/product',this.id]);
  }
}
