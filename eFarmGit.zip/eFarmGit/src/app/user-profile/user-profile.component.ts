import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapService } from '../cap.service';
import { User } from '../Model/User';
import { Wallet } from '../Model/Wallet';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  id: number;
  user: User = new User();
  status:any;
  curwalletBalance:number;
  constructor(private _service: CapService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.id = Number(this.route.snapshot.paramMap.get('Id'));
    this._service.getUserName().subscribe(data =>
      this.user = data
    )

    this._service.getWalletBalance().subscribe((data:Wallet)=>  {

      if(data!=null){
        this.curwalletBalance = data.walletBalance;
      }
      else{
        this.curwalletBalance = 0 ;
      }

      });
  }

  editUser(): any {

    this.router.navigate(['/editProfile', this.id]);
  }

  onSubmit(walletForm:any){
    this._service.addMoney(walletForm).subscribe( (data:Boolean)=>{
      this.status=data;
      if(this.status){
      console.log(this.status);
     alert("Notification sent to admin")
      
      }
      else{
        alert("User already exist");
        console.log(this.status);
        this.router.navigate(['/login']);
      }
  });
}
}
