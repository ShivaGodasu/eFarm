import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapService } from '../cap.service';
import { User } from '../Model/User';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  id: number;
  user: User = new User();
  status:any;
  constructor(private _service: CapService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.id = Number(this.route.snapshot.paramMap.get('Id'));
    this._service.getUserName().subscribe(data =>
      this.user = data
    )
  }

  editUser(): any {

    this.router.navigate(['/editProfile', this.id]);
  }

  onSubmit(walletForm:any){
    this._service.addMoney(walletForm).subscribe( data =>
      this.status=data)

  }
}
