import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CapService } from '../cap.service';
import { Product } from '../Model/Product_Info';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  selectedFile: File;
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
  imageName: any;
  status:Boolean;
 
  constructor(private capService:CapService,private router:Router,private toastr:ToastrService) { }
  
  // onFileChanged(event) {
  //   this.selectedFile = event.target.files[0];
  // }

  onSubmit(addProductForm:Product){
    
  // console.log(this.selectedFile);
  // console.log(addProductForm);
  this.capService.addProduct(addProductForm).subscribe((data:Boolean)=>{
        this.status=data;
        if(this.status){
        console.log(this.status);
        this.message="Added Successfully..."
        alert(this.message);
        this.router.navigate(['/userHome']);
        }
        else{
         // this.message="User is alredy existing"
          console.log(this.status);

        }
      });

  }
 
  ngOnInit(): void {
  }

}
